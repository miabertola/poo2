
const Account=function(clock = () => new Date()){
    const movimientos = []
    let balance = 0

    const pad = (n) => String(n).padStart(2, '0')
    const formatDate = (d) =>
      `${pad(d.getDate())}/${pad(d.getMonth() + 1)}/${d.getFullYear()}`

    const register = (amount) => {
      balance += amount
      movimientos.push({ date: clock(), amount, balance })
    }
  
    this.deposit = function(amount){
      register(amount)
    }

    this.withdraw = function(amount){
      if (amount > balance) {
        throw new Error('Fondos insuficientes')
      }
      register(-amount)
    }

    this.printStatement=function(){
      const lines = movimientos.map(m => `${formatDate(m.date)} || ${m.amount} || ${m.balance}`)
      .reverse()
    return ['Date || Amount || Balance', ...lines]
    }
}

const Transaction = function(date, amount){
    this.format = function (runningBalance){
        return `${date} || ${amount} || ${this.getRunningBalanceWith(runningBalance)}`
    }

    this.compareWith = function (anotherTransaction){
        return date.localeCompare(anotherTransaction.getDate())
    }

    this.getDate = () => date;

    this.getRunningBalanceWith = function (currentBalance){
        return amount + currentBalance
    }
}

module.exports = Account;
