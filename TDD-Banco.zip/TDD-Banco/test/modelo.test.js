const Account = require('../src/modelo');

const clockWith = (...dates) => {
  let i = 0
  return () => dates[i++]
}

test('Cuenta debe iniciar sin statements', () => {
  const account = new Account()

  expect(account.printStatement()).toEqual(['Date || Amount || Balance'])
});

test('Se debe poder depositar en una cuenta', () => {
  const account = new Account(clockWith(new Date(2026,9,7)))
  
  account.deposit(10)
  
  expect(account.printStatement()).toEqual(
    ['Date || Amount || Balance',
    '07/10/2026 || 10 || 10'])
});

test('Se debe poder depositar en una cuenta', () => {
  const account = new Account(clockWith(new Date(2026,9,7)))
  
  account.deposit(100)
  
  expect(account.printStatement()).toEqual(
    ['Date || Amount || Balance',
    '07/10/2026 || 100 || 100'])
});

test('Se debe poder retirar dinero de una cuenta', () => {
  const account = new Account(clockWith(new Date(2026,9,7), new Date(2026,9,8)))

  account.deposit(100)
  account.withdraw(50)

  expect(account.printStatement()).toEqual(
    ['Date || Amount || Balance',
    '08/10/2026 || -50 || 50',
    '07/10/2026 || 100 || 100'])
});

test('No se puede retirar dinero de una cuenta vacía', () => {
  const account = new Account(clockWith(new Date(2010,0,10)))

  expect(() => account.withdraw(150)).toThrow('Fondos insuficientes')
  expect(account.printStatement()).toEqual(['Date || Amount || Balance'])
});

test('Dos depósitos acumulan el saldo', () => {
  const account = new Account(clockWith(new Date(2026,9,7), new Date(2026,9,7)))

  account.deposit(100)
  account.deposit(50)

  expect(account.printStatement()).toEqual([
    'Date || Amount || Balance',
    '07/10/2026 || 50 || 150',
    '07/10/2026 || 100 || 100'])
});

test('Cada movimiento lleva su fecha', () => {
  const account = new Account(clockWith(new Date(2012, 0, 10), new Date(2012, 0, 13)))

  account.deposit(1000)
  account.deposit(2000)

  expect(account.printStatement()).toEqual([
    'Date || Amount || Balance',
    '13/01/2012 || 2000 || 3000',
    '10/01/2012 || 1000 || 1000'])
});

test('Ejemplo completo', () => {
  const account = new Account(clockWith(new Date(2012, 0, 10), new Date(2012, 0, 13),new Date(2012, 0, 14)))

  account.deposit(1000)
  account.deposit(2000)
  account.withdraw(500)

  expect(account.printStatement()).toEqual([
    'Date || Amount || Balance',
    '14/01/2012 || -500 || 2500',
    '13/01/2012 || 2000 || 3000',
    '10/01/2012 || 1000 || 1000'])
});
