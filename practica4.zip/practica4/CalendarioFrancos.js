const CalendarioFrancos = function(){
    this.francos = [];
}

CalendarioFrancos.prototype.agregarFranco = function(franco){
    this.francos.push(franco);
}

CalendarioFrancos.prototype.esFranco = function(fecha){
    let franco = this.francos.find(franco => franco.esFranco(fecha));
    return franco != undefined;
}

module.exports = CalendarioFrancos;