const Empleado=function(nombre,apellido, area, pais, empresa){
    this.nombre = nombre;
    this.apellido = apellido;
    this.area = area;
    this.pais = pais;
    this.francos=[empresa,pais,area];

    this.agregarFranco=function(franco){
        this.francos.push(franco);
    }

    this.buscarFranco=function(fecha){
        let esFranco = this.francos.find(franco=>franco.esFranco(fecha));
        esFranco = (esFranco != undefined);
        return esFranco;
    }
}

module.exports = Empleado;