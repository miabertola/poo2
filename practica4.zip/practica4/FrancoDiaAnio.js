const FrancoDiaAnio=function(dia,anio){
    this.dia=dia;
    this.anio=anio;
}

FrancoDiaAnio.prototype.esFranco=function(fecha){
    return (
        this.dia===fecha.getDate() &&
        this.anio===fecha.getFullYear()
    );
}

module.exports = FrancoDiaAnio;