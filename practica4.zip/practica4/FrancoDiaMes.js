const FrancoDiaMes = function(dia, mes){
    this.dia = dia;
    this.mes = mes;
}

FrancoDiaMes.prototype.esFranco = function(fecha){
    return(
        this.dia === fecha.getDate() &&
        this.mes === fecha.getMonth()
    );
}

module.exports = FrancoDiaMes;