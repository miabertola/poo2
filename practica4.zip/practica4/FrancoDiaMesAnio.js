const FrancoDiaMesAnio = function(dia, mes, anio){
    this.dia = dia;
    this.mes = mes;
    this.anio = anio;
}

FrancoDiaMesAnio.prototype.esFranco = function(fecha){
    return (
        this.dia === fecha.getDate() &&
        this.mes === fecha.getMonth() &&
        this.anio === fecha.getFullYear()
    );
}

module.exports = FrancoDiaMesAnio;