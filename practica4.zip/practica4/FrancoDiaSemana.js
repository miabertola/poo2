const FrancoDiaSemana=function(diaSemana){
    this.diaSemana = diaSemana;
}

FrancoDiaSemana.prototype.esFranco = function(fecha){
    return (
        this.diaSemana === fecha.getDay()
    );
}

module.exports = FrancoDiaSemana;