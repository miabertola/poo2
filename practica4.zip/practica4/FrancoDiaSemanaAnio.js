const FrancoDiaSemanaAnio = function(diaSemana, anio){
    this.diaSemana = diaSemana;
    this.anio = anio;
}

FrancoDiaSemanaAnio.prototype.esFranco = function(fecha){
    return (
        this.diaSemana === fecha.getDay() &&
        this.anio === fecha.getFullYear()
    );
}

module.exports = FrancoDiaSemanaAnio;