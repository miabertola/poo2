const FrancoDiaSemanaMes = function(diaSemana, mes){
    this.diaSemana = diaSemana;
    this.mes = mes;
}

FrancoDiaSemanaMes.prototype.esFranco = function(fecha){
    return (
        this.diaSemana === fecha.getDay() &&
        this.mes === fecha.getMonth()
    );
}

module.exports = FrancoDiaSemanaMes ;