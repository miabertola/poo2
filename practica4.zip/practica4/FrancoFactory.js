const FrancoDiaAnio = require("./FrancoDiaAnio");
const FrancoDiaMes = require("./FrancoDiaMes");
const FrancoDiaMesAnio = require("./FrancoDiaMesAnio");
const FrancoDiaSemana = require("./FrancoDiaSemana");
const FrancoDiaSemanaAnio = require("./FrancoDiaSemanaAnio");
const FrancoDiaSemanaMes = require("./FrancoDiaSemanaMes");
const FrancoMesAnio = require("./FrancoMesAnio");

const crearFranco = function(tipo,datos){
    switch(tipo){
        case "FrancoDiaAnio":
            return new FrancoDiaAnio(datos.dia, datos.anio);

        case "FrancoDiaMes":
            return new FrancoDiaMes(datos.dia, datos.mes);

        case "FrancoDiaMesAnio":
            return new FrancoDiaMesAnio(datos.dia, datos.mes, datos.anio);

        case "FrancoDiaSemana":
            return new FrancoDiaSemana(datos.diaSemana);

        case "FrancoDiaSemanaAnio":
            return new FrancoDiaSemanaAnio(datos.diaSemana, datos.anio);

        case "FrancoDiaSemanaMes":
            return new FrancoDiaSemanaMes(datos.diaSemana, datos.mes);
        
        case "FrancoMesAnio":
            return new FrancoMesAnio(datos.mes, datos.anio);
        
        default:
            throw new Error("Tipo de franco desconocido: " + tipo);
    }
}

module.exports = crearFranco;