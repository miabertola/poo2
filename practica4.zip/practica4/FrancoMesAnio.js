const FrancoMesAnio = function(mes, anio){
    this.mes = mes;
    this.anio = anio;
}

FrancoMesAnio.prototype.esFranco = function(fecha){
    return (
        this.mes === fecha.getMonth() &&
        this.anio === fecha.getFullYear()
    );
}

module.exports = FrancoMesAnio;