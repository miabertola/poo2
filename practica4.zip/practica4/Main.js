const Empleado = require("./Empleado");
const CalendarioFrancos = require("./CalendarioFrancos");
const crearFranco = require("./FrancoFactory");

// ---- Calendarios compartidos ----
const calendarioEmpresa = new CalendarioFrancos();
const calendarioArgentina = new CalendarioFrancos();
const calendarioColombia = new CalendarioFrancos();
const calendarioVentas = new CalendarioFrancos();
const calendarioProducto = new CalendarioFrancos();
const calendarioDesarrollo = new CalendarioFrancos();
const calendarioRRHH = new CalendarioFrancos();

calendarioEmpresa.agregarFranco(crearFranco("FrancoDiaMes", {dia: 25, mes: 11}));    // 25/12
calendarioArgentina.agregarFranco(crearFranco("FrancoDiaMes", {dia: 25, mes: 4}));   // 25/05
calendarioColombia.agregarFranco(crearFranco("FrancoDiaMes", {dia: 20, mes: 6}));    // 20/07
calendarioVentas.agregarFranco(crearFranco("FrancoDiaMes", {dia: 15, mes: 9}));      // 15/10
calendarioProducto.agregarFranco(crearFranco("FrancoDiaMes", {dia: 3, mes: 10}));    // 03/11

// ---- Empleados ----
const mia = new Empleado("Mia", "Bertola", calendarioVentas, calendarioArgentina, calendarioEmpresa);
const camila = new Empleado("Camila", "Rojas", calendarioProducto, calendarioColombia, calendarioEmpresa);
const francisco = new Empleado("Francisco", "Perez", calendarioDesarrollo, calendarioArgentina, calendarioEmpresa);

// ---- Francos particulares ----
mia.agregarFranco(crearFranco("FrancoDiaMesAnio", {dia: 15, mes: 5, anio: 2026}));
mia.agregarFranco(crearFranco("FrancoDiaSemana", {diaSemana: 3}));
francisco.agregarFranco(crearFranco("FrancoDiaSemanaMes", {diaSemana: 2, mes: 8}));

// ---- Pruebas ----
const probar = function(empleado, fecha, esperado, descripcion){
    const resultado = empleado.buscarFranco(new Date(fecha + "T10:20:00Z"));
    const estado = resultado === esperado ? "OK   " : "ERROR";
    console.log(estado, empleado.nombre, fecha, "->", resultado, "|", descripcion);
}

// Particulares
probar(mia, "2026-06-15", true, "particular de Mia (15/06/2026)");
probar(camila, "2026-06-15", false, "el particular de Mia no aplica a Camila");
probar(mia, "2026-09-16", true, "miércoles (particular de Mia)");
probar(francisco, "2026-09-16", false, "Francisco no tiene los miércoles");
probar(francisco, "2026-09-08", true, "martes de septiembre");
probar(francisco, "2026-10-06", false, "martes, pero de octubre");

// Empresa (aplica a todos)
probar(mia, "2026-12-25", true, "empresa");
probar(camila, "2026-12-25", true, "empresa");
probar(francisco, "2026-12-25", true, "empresa");

// País
probar(mia, "2026-05-25", true, "feriado de Argentina");
probar(francisco, "2026-05-25", true, "feriado de Argentina");
probar(camila, "2026-05-25", false, "Colombia no tiene el 25/05");
probar(camila, "2026-07-20", true, "feriado de Colombia");
probar(mia, "2026-07-20", false, "Argentina no tiene el 20/07");

// Área
probar(mia, "2026-10-15", true, "feriado de Ventas");
probar(camila, "2026-10-15", false, "Producto no tiene el 15/10");
probar(camila, "2026-11-03", true, "feriado de Producto");
probar(francisco, "2026-11-03", false, "Desarrollo no tiene el 03/11");

// Ningún franco
probar(mia, "2026-03-10", false, "día común");
probar(camila, "2026-03-10", false, "día común");