const FrancoDiaAnio = require("../FrancoDiaAnio");
const FrancoDiaMes = require("../FrancoDiaMes");
const FrancoDiaMesAnio = require("../FrancoDiaMesAnio");
const FrancoDiaSemana = require("../FrancoDiaSemana");
const FrancoDiaSemanaAnio = require("../FrancoDiaSemanaAnio");
const FrancoDiaSemanaMes = require("../FrancoDiaSemanaMes");
const FrancoMesAnio = require("../FrancoMesAnio");
const CalendarioFrancos = require("../CalendarioFrancos");
const Empleado = require("../Empleado");
const crearFranco = require("../FrancoFactory");

// Atajo para las fechas nuevas (getMonth va de 0 a 11, getDay de 0=domingo a 6=sábado)
const fecha = (iso) => new Date(iso + "T10:20:00Z");


describe("FrancoDiaSemana", () => {
    test("es franco si la fecha cae en ese día de la semana", () => {
        const franco = new FrancoDiaSemana(3); // miércoles
        expect(franco.esFranco(new Date("2026-09-16T10:20:00Z"))).toBe(true);
    });

    test("no es franco si cae en otro día de la semana", () => {
        const franco = new FrancoDiaSemana(3);
        expect(franco.esFranco(new Date("2026-09-15T10:20:00Z"))).toBe(false);
    });

    test("es franco todos los miércoles, sin importar mes ni año", () => {
        const franco = new FrancoDiaSemana(3);
        expect(franco.esFranco(fecha("2026-06-03"))).toBe(true);
        expect(franco.esFranco(fecha("2027-09-15"))).toBe(true);
    });
});

describe("FrancoDiaSemanaMes", () => {
    const martesDeSeptiembre = new FrancoDiaSemanaMes(2, 8);

    test("es franco un martes de septiembre", () => {
        expect(martesDeSeptiembre.esFranco(new Date("2026-09-08T10:20:00Z"))).toBe(true);
    });

    test("no es franco un martes de otro mes", () => {
        expect(martesDeSeptiembre.esFranco(new Date("2026-10-06T10:20:00Z"))).toBe(false);
    });

    test("no es franco otro día de septiembre", () => {
        expect(martesDeSeptiembre.esFranco(new Date("2026-09-02T10:20:00Z"))).toBe(false);
    });

    test("es franco un martes de septiembre de otro año", () => {
        expect(martesDeSeptiembre.esFranco(fecha("2027-09-07"))).toBe(true);
    });
});

describe("FrancoDiaMesAnio (un día en particular del año)", () => {
    const franco = new FrancoDiaMesAnio(15, 5, 2026); // 15/06/2026

    test("es franco en esa fecha exacta", () => {
        expect(franco.esFranco(fecha("2026-06-15"))).toBe(true);
    });

    test("no es franco otro día del mismo mes y año", () => {
        expect(franco.esFranco(fecha("2026-06-16"))).toBe(false);
    });

    test("no es franco el mismo día en otro mes", () => {
        expect(franco.esFranco(fecha("2026-07-15"))).toBe(false);
    });

    test("no es franco el mismo día y mes en otro año", () => {
        expect(franco.esFranco(fecha("2027-06-15"))).toBe(false);
    });
});

describe("FrancoDiaMes (todos los años, mismo día y mes)", () => {
    const franco = new FrancoDiaMes(25, 4); // 25/05

    test("es franco ese día y mes de cualquier año", () => {
        expect(franco.esFranco(fecha("2026-05-25"))).toBe(true);
        expect(franco.esFranco(fecha("2027-05-25"))).toBe(true);
    });

    test("no es franco otro día del mismo mes", () => {
        expect(franco.esFranco(fecha("2026-05-26"))).toBe(false);
    });

    test("no es franco el mismo día en otro mes", () => {
        expect(franco.esFranco(fecha("2026-06-25"))).toBe(false);
    });
});

describe("FrancoDiaAnio (el mismo día de cada mes de un año)", () => {
    const franco = new FrancoDiaAnio(15, 2026);

    test("es franco el día 15 de cualquier mes de ese año", () => {
        expect(franco.esFranco(fecha("2026-01-15"))).toBe(true);
        expect(franco.esFranco(fecha("2026-07-15"))).toBe(true);
    });

    test("no es franco otro día de ese año", () => {
        expect(franco.esFranco(fecha("2026-07-16"))).toBe(false);
    });

    test("no es franco el día 15 de otro año", () => {
        expect(franco.esFranco(fecha("2027-07-15"))).toBe(false);
    });
});

describe("FrancoDiaSemanaAnio (un día de la semana de un año)", () => {
    const franco = new FrancoDiaSemanaAnio(3, 2026); // miércoles de 2026

    test("es franco un miércoles de ese año", () => {
        expect(franco.esFranco(fecha("2026-09-16"))).toBe(true);
        expect(franco.esFranco(fecha("2026-06-03"))).toBe(true);
    });

    test("no es franco otro día de la semana de ese año", () => {
        expect(franco.esFranco(fecha("2026-09-15"))).toBe(false);
    });

    test("no es franco un miércoles de otro año", () => {
        expect(franco.esFranco(fecha("2027-09-15"))).toBe(false);
    });
});

describe("FrancoMesAnio (un mes completo de un año)", () => {
    const franco = new FrancoMesAnio(8, 2026); // septiembre 2026

    test("es franco el primer y el último día del mes", () => {
        expect(franco.esFranco(fecha("2026-09-01"))).toBe(true);
        expect(franco.esFranco(fecha("2026-09-30"))).toBe(true);
    });

    test("no es franco el mes siguiente ni el anterior", () => {
        expect(franco.esFranco(fecha("2026-10-01"))).toBe(false);
        expect(franco.esFranco(fecha("2026-08-31"))).toBe(false);
    });

    test("no es franco el mismo mes de otro año", () => {
        expect(franco.esFranco(fecha("2027-09-15"))).toBe(false);
    });
});

describe("CalendarioFrancos", () => {
    test("un calendario vacío no tiene francos", () => {
        const calendario = new CalendarioFrancos();
        expect(calendario.esFranco(new Date("2026-09-16T10:20:00Z"))).toBe(false);
    });

    test("es franco si alguno de sus francos aplica", () => {
        const calendario = new CalendarioFrancos();
        calendario.agregarFranco(new FrancoDiaSemana(3));
        expect(calendario.esFranco(new Date("2026-09-16T10:20:00Z"))).toBe(true);
    });

    test("no es franco si ninguno de sus francos aplica", () => {
        const calendario = new CalendarioFrancos();
        calendario.agregarFranco(new FrancoDiaSemana(3));
        calendario.agregarFranco(new FrancoDiaMes(25, 4));
        expect(calendario.esFranco(fecha("2026-09-15"))).toBe(false);
    });

    test("es franco si aplica cualquiera de varios francos", () => {
        const calendario = new CalendarioFrancos();
        calendario.agregarFranco(new FrancoDiaSemana(3));
        calendario.agregarFranco(new FrancoDiaMes(25, 4));
        expect(calendario.esFranco(fecha("2026-09-16"))).toBe(true); // por el primero
        expect(calendario.esFranco(fecha("2026-05-25"))).toBe(true); // por el segundo
    });

    test("un franco agregado después también se tiene en cuenta", () => {
        const calendario = new CalendarioFrancos();
        expect(calendario.esFranco(fecha("2026-08-17"))).toBe(false);
        calendario.agregarFranco(new FrancoDiaMes(17, 7));
        expect(calendario.esFranco(fecha("2026-08-17"))).toBe(true);
    });

    test("un calendario puede contener otro calendario", () => {
        const interno = new CalendarioFrancos();
        interno.agregarFranco(new FrancoDiaMes(25, 4));
        const externo = new CalendarioFrancos();
        externo.agregarFranco(interno);
        expect(externo.esFranco(fecha("2026-05-25"))).toBe(true);
        expect(externo.esFranco(fecha("2026-05-26"))).toBe(false);
    });
});

describe("crearFranco", () => {
    test("crea un franco que responde esFranco", () => {
        const franco = crearFranco("FrancoDiaSemana", {diaSemana: 3});
        expect(franco.esFranco(new Date("2026-09-16T10:20:00Z"))).toBe(true);
    });

    test("tira error con un tipo desconocido", () => {
        expect(() => crearFranco("Inexistente", {})).toThrow();
    });

    test("FrancoDiaMesAnio", () => {
        const franco = crearFranco("FrancoDiaMesAnio", {dia: 15, mes: 5, anio: 2026});
        expect(franco.esFranco(fecha("2026-06-15"))).toBe(true);
        expect(franco.esFranco(fecha("2026-06-16"))).toBe(false);
    });

    test("FrancoDiaMes", () => {
        const franco = crearFranco("FrancoDiaMes", {dia: 25, mes: 4});
        expect(franco.esFranco(fecha("2027-05-25"))).toBe(true);
        expect(franco.esFranco(fecha("2027-06-25"))).toBe(false);
    });

    test("FrancoDiaAnio", () => {
        const franco = crearFranco("FrancoDiaAnio", {dia: 15, anio: 2026});
        expect(franco.esFranco(fecha("2026-07-15"))).toBe(true);
        expect(franco.esFranco(fecha("2027-07-15"))).toBe(false);
    });

    test("FrancoDiaSemanaAnio", () => {
        const franco = crearFranco("FrancoDiaSemanaAnio", {diaSemana: 3, anio: 2026});
        expect(franco.esFranco(fecha("2026-09-16"))).toBe(true);
        expect(franco.esFranco(fecha("2027-09-15"))).toBe(false);
    });

    test("FrancoDiaSemanaMes", () => {
        const franco = crearFranco("FrancoDiaSemanaMes", {diaSemana: 2, mes: 8});
        expect(franco.esFranco(fecha("2026-09-08"))).toBe(true);
        expect(franco.esFranco(fecha("2026-10-06"))).toBe(false);
    });

    test("FrancoMesAnio", () => {
        const franco = crearFranco("FrancoMesAnio", {mes: 8, anio: 2026});
        expect(franco.esFranco(fecha("2026-09-20"))).toBe(true);
        expect(franco.esFranco(fecha("2026-10-20"))).toBe(false);
    });
});

describe("Empleado", () => {
    let calendarioEmpresa, calendarioArgentina, calendarioColombia;
    let calendarioVentas, calendarioProducto;
    let mia, francisco, camila;

    beforeEach(() => {
        calendarioEmpresa = new CalendarioFrancos();
        calendarioArgentina = new CalendarioFrancos();
        calendarioColombia = new CalendarioFrancos();
        calendarioVentas = new CalendarioFrancos();
        calendarioProducto = new CalendarioFrancos();

        calendarioEmpresa.agregarFranco(crearFranco("FrancoDiaMes", {dia: 25, mes: 11}));   // 25/12
        calendarioArgentina.agregarFranco(crearFranco("FrancoDiaMes", {dia: 25, mes: 4}));  // 25/05
        calendarioColombia.agregarFranco(crearFranco("FrancoDiaMes", {dia: 20, mes: 6}));   // 20/07
        calendarioVentas.agregarFranco(crearFranco("FrancoDiaMes", {dia: 15, mes: 9}));     // 15/10
        calendarioProducto.agregarFranco(crearFranco("FrancoDiaMes", {dia: 3, mes: 10}));   // 03/11

        mia = new Empleado("Mia", "Bertola", calendarioVentas, calendarioArgentina, calendarioEmpresa);
        francisco = new Empleado("Francisco", "Perez", calendarioProducto, calendarioArgentina, calendarioEmpresa);
        camila = new Empleado("Camila", "Rojas", calendarioVentas, calendarioColombia, calendarioEmpresa);
    });

    describe("francos particulares", () => {
        test("aplica al empleado que lo tiene", () => {
            mia.agregarFranco(crearFranco("FrancoDiaMesAnio", {dia: 15, mes: 5, anio: 2026}));
            expect(mia.buscarFranco(fecha("2026-06-15"))).toBe(true);
        });

        test("no aplica a otros empleados", () => {
            mia.agregarFranco(crearFranco("FrancoDiaMesAnio", {dia: 15, mes: 5, anio: 2026}));
            expect(francisco.buscarFranco(fecha("2026-06-15"))).toBe(false);
            expect(camila.buscarFranco(fecha("2026-06-15"))).toBe(false);
        });

        test("Francisco tiene libres los martes de septiembre", () => {
            francisco.agregarFranco(crearFranco("FrancoDiaSemanaMes", {diaSemana: 2, mes: 8}));
            expect(francisco.buscarFranco(fecha("2026-09-08"))).toBe(true);   // martes de septiembre
            expect(francisco.buscarFranco(fecha("2026-09-02"))).toBe(false);  // miércoles
            expect(francisco.buscarFranco(fecha("2026-10-06"))).toBe(false);  // martes de octubre
        });
    });

    describe("francos de la empresa", () => {
        test("aplican a todos los empleados, sin importar país ni área", () => {
            expect(mia.buscarFranco(fecha("2026-12-25"))).toBe(true);
            expect(francisco.buscarFranco(fecha("2026-12-25"))).toBe(true);
            expect(camila.buscarFranco(fecha("2026-12-25"))).toBe(true);
        });
    });

    describe("francos por país", () => {
        test("el feriado de Argentina aplica a los empleados argentinos", () => {
            expect(mia.buscarFranco(fecha("2026-05-25"))).toBe(true);
            expect(francisco.buscarFranco(fecha("2026-05-25"))).toBe(true);
        });

        test("el feriado de Argentina no aplica a los colombianos", () => {
            expect(camila.buscarFranco(fecha("2026-05-25"))).toBe(false);
        });

        test("el feriado de Colombia aplica a los colombianos y no a los argentinos", () => {
            expect(camila.buscarFranco(fecha("2026-07-20"))).toBe(true);
            expect(mia.buscarFranco(fecha("2026-07-20"))).toBe(false);
            expect(francisco.buscarFranco(fecha("2026-07-20"))).toBe(false);
        });
    });

    describe("francos por área", () => {
        test("el feriado de Ventas aplica a Ventas, de cualquier país", () => {
            expect(mia.buscarFranco(fecha("2026-10-15"))).toBe(true);
            expect(camila.buscarFranco(fecha("2026-10-15"))).toBe(true);
        });

        test("el feriado de Ventas no aplica a otras áreas", () => {
            expect(francisco.buscarFranco(fecha("2026-10-15"))).toBe(false);
        });

        test("el feriado de Producto aplica solo a Producto", () => {
            expect(francisco.buscarFranco(fecha("2026-11-03"))).toBe(true);
            expect(mia.buscarFranco(fecha("2026-11-03"))).toBe(false);
            expect(camila.buscarFranco(fecha("2026-11-03"))).toBe(false);
        });
    });

    describe("calendarios compartidos", () => {
        test("un feriado agregado después al calendario del país le llega a todos sus empleados", () => {
            expect(mia.buscarFranco(fecha("2026-08-17"))).toBe(false);
            expect(francisco.buscarFranco(fecha("2026-08-17"))).toBe(false);

            calendarioArgentina.agregarFranco(crearFranco("FrancoDiaMes", {dia: 17, mes: 7}));

            expect(mia.buscarFranco(fecha("2026-08-17"))).toBe(true);
            expect(francisco.buscarFranco(fecha("2026-08-17"))).toBe(true);
            expect(camila.buscarFranco(fecha("2026-08-17"))).toBe(false);
        });
    });

    test("un día común no es franco para nadie", () => {
        expect(mia.buscarFranco(fecha("2026-03-10"))).toBe(false);
        expect(francisco.buscarFranco(fecha("2026-03-10"))).toBe(false);
        expect(camila.buscarFranco(fecha("2026-03-10"))).toBe(false);
    });
});