const ComandoFactory = function(comando) {
    switch (comando){
        case "W":
            return new ComandoW();
        case "S":
            return new ComandoS();
        case "D":
            return new ComandoD();
        case "A":
            return new ComandoA();
        default:
            throw new Error("Comando desconocido")
    }
}

const ComandoW = function() {
    this.mover = (x, y) => {
        return [x, y + 1];
    }
}

const ComandoS = function() {
    this.mover = (x, y) => {
        return [x, y - 1];
    }
}

const ComandoD = function() {
    this.mover = (x, y) => {
        return [x + 1, y];
    }
}

const ComandoA = function() {
    this.mover = (x, y) => {
        return [x - 1, y];
    }
}

module.exports = ComandoFactory ;