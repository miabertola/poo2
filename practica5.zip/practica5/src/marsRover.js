const ComandoFactory = require("./comandos");

const MarsRover=function(x,y){
    this.x=x;
    this.y=y;

    this.obtenerPosicion= () => [this.x,this.y];

    this.mover = (letra) => {
        const accion = ComandoFactory(letra);
        const nuevaPosicion = accion.mover(this.x, this.y);
        this.x = nuevaPosicion[0];
        this.y = nuevaPosicion[1];
    }
}

module.exports= MarsRover;