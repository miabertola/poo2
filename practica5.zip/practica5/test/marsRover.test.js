const MarsRover = require("../src/marsRover")

test("Mars rover aterriza en una posicion inicial configurable: 50,50", ()=> {
    //setup
    const rover = new MarsRover(50,50);

    //exercise
    const posicionInicial= rover.obtenerPosicion();

    //assert

    expect(posicionInicial).toEqual([50,50]);
})

test("Mars rover aterriza en una posicion inicial configurable: 0,0", ()=> {
    const rover = new MarsRover(0,0);

    const posicionInicial= rover.obtenerPosicion();

    expect(posicionInicial).toEqual([0,0]);
})

test('Mars Rover recibe un comando W y avanza a posicion 50,51', () => {
    const rover = new MarsRover(50,50);

    rover.mover("W");

    expect(rover.obtenerPosicion()).toEqual([50,51])
});

test('Mars Rover recibe dos comandos consecutivos W y avanza a posicion 50,52', () => {
    const rover = new MarsRover(50,50);

    rover.mover("W");
    rover.mover("W");

    expect(rover.obtenerPosicion()).toEqual([50,52])
});

test('Mars Rover recibe un comando S y retrocede a la posicion 50,49', () => {
    const rover = new MarsRover(50,50);

    rover.mover("S");

    expect(rover.obtenerPosicion()).toEqual([50,49])
});

test('Mars Rover recibe un comando D y se desplaza a la posicion 51,50', () => {
    const rover = new MarsRover(50,50);

    rover.mover("D");

    expect(rover.obtenerPosicion()).toEqual([51,50])
})

test('Mars Rover recibe un comando A y se desplaza a la posicion 49,50', () => {
    const rover = new MarsRover(50,50);

    rover.mover("A");

    expect(rover.obtenerPosicion()).toEqual([49,50]);
});

test('Mars Rover recibe un comando desconocido, lo rechaza y no se mueve', () => {
    const rover = new MarsRover(50,50);

    expect(()=>rover.mover("Q")).toThrow(new Error("Comando desconocido"))
    expect(()=>rover.mover("C")).toThrow(new Error("Comando desconocido"))
    expect(()=>rover.mover("P")).toThrow(new Error("Comando desconocido"))

    expect(rover.obtenerPosicion()).toEqual([50,50])
})