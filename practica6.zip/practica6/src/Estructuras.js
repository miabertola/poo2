const Pila = function(){
    this.tos = null;

    this.estaVacia = function(){
        return this.tos===null;
    }

    this.push = function(ele){
        const nodo = new Nodo();
        nodo.valor = ele;
        nodo.sig = this.tos;
        this.tos = nodo;
    }

    this.pop = function(){
        if(this.estaVacia()){
            throw new Error ("Error. La pila esta vacia");
        }
        let ele = this.tos.valor;
        this.tos = this.tos.sig;
        return ele;
    }
}

const Nodo = function(){
    this.valor = null;
    this.sig = null;
}

const Cola = function(){
    this.front = null;
    this.rear = null;

    this.estaVacia = function(){
        return this.front===null;
    }

    this.encolar = function(ele){
            const nodo = new Nodo();
            nodo.valor = ele;
            if(this.estaVacia()){
                this.front = nodo;
                this.rear = nodo;
            }
            else{
                this.rear.sig = nodo;
                this.rear = nodo;
            }
    }

    this.desencolar = function(){
        if(this.estaVacia()){
            throw new Error("Error. Cola vacia")
        }
        let ele = this.front.valor;
        this.front = this.front.sig;
        if(this.estaVacia()){
            this.rear = null;
        }
        return ele;
    }
}

module.exports = { Pila, Cola };