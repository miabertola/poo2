const Pila = function(){
    this.tos = null;

    this.estaVacia = function(){
        return this.tos===null;
    }

    this.push = function(ele){
        const nodo = new Nodo();
        nodo.asignarValor(ele);
        nodo.asignarSig(this.tos);
        this.tos = nodo;
    }

    this.pop = function(){
        if(this.estaVacia()){
            throw new Error ("Error. La pila esta vacia");
        }
        let ele = this.tos.obtenerValor();
        this.tos = this.tos.obtenerSig();
        return ele;
    }
}

const Nodo = function(){
    this.valor = null;
    this.sig = null;

    this.obtenerValor = function(){
        return this.valor;
    }

    this.obtenerSig = function(){
        return this.sig;
    }

    this.asignarValor = function(ele){
        this.valor = ele;
    }

    this.asignarSig = function(ele){
        this.sig = ele;
    }
}

const Cola = function(){
    this.front = null;
    this.rear = null;

    this.estaVacia = function(){
        return this.front===null;
    }

    this.encolar = function(ele){
            const nodo = new Nodo();
            nodo.asignarValor(ele);
            if(this.estaVacia()){
                this.front = nodo;
                this.rear = nodo;
            }
            else{
                this.rear.asignarSig(nodo);
                this.rear = nodo;
            }
    }

    this.desencolar = function(){
        if(this.estaVacia()){
            throw new Error("Error. Cola vacia")
        }
        let ele = this.front.obtenerValor();
        this.front = this.front.obtenerSig();
        if(this.estaVacia()){
            this.rear = null;
        }
        return ele;
    }
}

module.exports = { Pila, Cola };