const { Pila, Cola } = require("../src/Estructuras")

test('Una pila recien creada esta vacia', () => {
    const pila = new Pila();

    expect(pila.estaVacia()).toEqual(true)
});

test('A una pila se le puede agregar un elemento', () => {
    const pila = new Pila();

    pila.push(3);

    expect(pila.estaVacia()).toEqual(false)
});

test('A una pila se le puede agregar un elemento 0 y no estara vacia', () => {
    const pila = new Pila();

    pila.push(0);

    expect(pila.estaVacia()).toEqual(false)
});

test('A una pila se le puede quitar un elemento', () => {
    const pila = new Pila();

    pila.push(3);

    expect(pila.pop()).toEqual(3)
    expect(pila.estaVacia()).toEqual(true)
});

test('A una pila se le puede agregar mas de un elemento y elimina el ultimo elemento', () => {
    const pila = new Pila();

    pila.push(3);
    pila.push(4);

    expect(pila.pop()).toEqual(4)
    expect(pila.pop()).toEqual(3)
});

test('A una pila se le pueden agregar 3 elementos y se sacaran en orden LIFO', () => {
    const pila = new Pila();

    pila.push(1);
    pila.push(2);
    pila.push(3);

    expect(pila.pop()).toEqual(3)
    expect(pila.pop()).toEqual(2)
    expect(pila.pop()).toEqual(1)
});

test('No se puede quitar un elemento de una pila que esta vacia', () => {
    const pila = new Pila();

    expect( () => pila.pop()).toThrow("Error. La pila esta vacia")
});

test('Una cola recien creada esta vacia', () => {
    const cola = new Cola();

    expect(cola.estaVacia()).toEqual(true)
});

test('A una cola se le puede agregar un elemento', () => {
    const cola = new Cola();

    cola.encolar(3);

    expect(cola.estaVacia()).toEqual(false)
});

test('A una cola se le puede eliminar un elemento', () => {
    const cola = new Cola();

    cola.encolar(3);
    cola.desencolar();

    expect(cola.estaVacia()).toEqual(true)
});

test('A una cola se le puede agregar mas de un elemento y eliminara el primer elemento', () => {
    const cola = new Cola();

    cola.encolar(1);
    cola.encolar(2);

    expect(cola.desencolar()).toEqual(1);
    expect(cola.desencolar()).toEqual(2);
});

test('A una cola se le pueden agregar 3 elementos y los elimina en orden FIFO', () => {
    const cola = new Cola();

    cola.encolar(1);
    cola.encolar(2);
    cola.encolar(3);
    
    expect(cola.desencolar()).toEqual(1);
    expect(cola.desencolar()).toEqual(2);
    expect(cola.desencolar()).toEqual(3);
});

test('A una cola se le pueden agregar y eliminar elementos y reutilizarla', () => {
    const cola = new Cola();

    cola.encolar(1);
    expect(cola.desencolar()).toEqual(1);

    cola.encolar(2);
    expect(cola.desencolar()).toEqual(2);

    cola.encolar(3);
    expect(cola.desencolar()).toEqual(3);

    expect(cola.estaVacia()).toEqual(true)
});

test('A una cola vacia no se le pueden eliminar elementos', () => {
    const cola = new Cola();

    expect( () => cola.desencolar()).toThrow("Error. Cola vacia")
})