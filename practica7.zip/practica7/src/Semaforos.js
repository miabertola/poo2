const SemaforoVehicular = function(intervalo_max){
    if(intervalo_max < 30 || intervalo_max > 90 || intervalo_max % 15 !== 0){
        throw new Error("El intervalo debe ser multiplo de 15 y estar entre 30 y 90 segundos")
    }
    this.intervalo_max = intervalo_max;
    this.segEnVerde = 0;
    this.estaEnVerde = false;

    this.habilitar = function(){
        this.estaEnVerde = true;
        this.segEnVerde = 0;
    }

    this.deshabilitar = function(){
        this.estaEnVerde = false;
    }

    this.pasaronQuinceSegundos = function(){
        this.segEnVerde += 15;
    }

    this.terminoSuTurno = function(){
        return this.segEnVerde >= this.intervalo_max;
    }

    this.estaHabilitado = function(){
        return this.estaEnVerde;
    }
}

const CrucePeatonal = function(intervalo_max){
    if(intervalo_max < 30 || intervalo_max > 90 || intervalo_max % 15 !== 0){
        throw new Error("El intervalo debe ser multiplo de 15 y estar entre 30 y 90 segundos")
    }
    this.intervalo_max = intervalo_max;
    this.segHabilitado = 0;
    this.habilitado = false;

    this.habilitar = function(){
        this.habilitado = true;
        this.segHabilitado = 0;
    }

    this.deshabilitar = function(){
        this.habilitado = false;
    }

    this.pasaronQuinceSegundos = function(){
        this.segHabilitado += 15;
    }

    this.terminoSuTurno = function(){
        return this.segHabilitado >= this.intervalo_max;
    }

    this.estaHabilitado = function(){
        return this.habilitado;
    }
}

const Interseccion = function(turnos){
    this.turnos = turnos;
    this.indiceActual = 0;

    this.turnoActual = function(){
        return this.turnos[this.indiceActual];
    }

    this.prender = function(){
        this.turnoActual().habilitar()
    }

    this.pasaronQuinceSegundos = function(){
        const turno = this.turnoActual();
        turno.pasaronQuinceSegundos();
        
        if (turno.terminoSuTurno()){
            turno.deshabilitar();
            this.indiceActual = (this.indiceActual + 1) % this.turnos.length;
            this.turnoActual().habilitar();
        }
    }
}

module.exports = { SemaforoVehicular, CrucePeatonal, Interseccion };