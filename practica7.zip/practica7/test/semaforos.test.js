const { SemaforoVehicular, CrucePeatonal, Interseccion } = require("../src/Semaforos")

test('Un semaforo de 30s termina su turno al segundo mensaje', () => {
    const semaforo = new SemaforoVehicular(30);
    semaforo.habilitar();
    semaforo.pasaronQuinceSegundos();
    semaforo.pasaronQuinceSegundos();
    
    expect(semaforo.terminoSuTurno()).toEqual(true)
});

test('Al cabo de 15 segundos, el semaforo no deberia haber terminado', () => {
    const semaforo = new SemaforoVehicular(30);
    semaforo.habilitar();
    semaforo.pasaronQuinceSegundos();
    
    expect(semaforo.terminoSuTurno()).toEqual(false)
});

test('Un intervalo invalido lanza error', () => {
    expect( () => new SemaforoVehicular(40)).toThrow("El intervalo debe ser multiplo de 15 y estar entre 30 y 90 segundos")
    expect( () => new SemaforoVehicular(50)).toThrow("El intervalo debe ser multiplo de 15 y estar entre 30 y 90 segundos")
});

test('Un cruce peatonal de 30s termina su turno al segundo mensaje', () => {
    const peatonal = new CrucePeatonal(30);
    peatonal.habilitar();
    peatonal.pasaronQuinceSegundos();
    peatonal.pasaronQuinceSegundos();

    expect(peatonal.terminoSuTurno()).toEqual(true)
});

test('Al prender, solo el primer turno esta habilitado', () => {
    const semaforo1 = new SemaforoVehicular(30);
    const semaforo2 = new SemaforoVehicular(45);
    const interseccion = new Interseccion([semaforo1, semaforo2]);

    interseccion.prender();

    expect(semaforo1.estaHabilitado()).toEqual(true)
    expect(semaforo2.estaHabilitado()).toEqual(false)
});

test('Pasa al turno siguiente y vuelve al primero', () => {
    const semaforo1 = new SemaforoVehicular(30);
    const semaforo2 = new SemaforoVehicular(45);
    const interseccion = new Interseccion([semaforo1, semaforo2]);

    interseccion.prender();
    interseccion.pasaronQuinceSegundos();
    interseccion.pasaronQuinceSegundos();

    expect(semaforo1.estaHabilitado()).toEqual(false)
    expect(semaforo2.estaHabilitado()).toEqual(true)

    interseccion.pasaronQuinceSegundos();
    interseccion.pasaronQuinceSegundos();
    interseccion.pasaronQuinceSegundos();

    expect(semaforo1.estaHabilitado()).toEqual(true)
    expect(semaforo2.estaHabilitado()).toEqual(false)
});

test('Nunca hay un semaforo y el peatonal habilitados a la vez', () => {
    const calle = new SemaforoVehicular(30);
    const peatonal = new CrucePeatonal(30);
    const interseccion = new Interseccion([calle, peatonal]);

    interseccion.prender();
    expect(calle.estaHabilitado()).toEqual(true)
    expect(peatonal.estaHabilitado()).toEqual(false)

    interseccion.pasaronQuinceSegundos();
    expect(calle.estaHabilitado()).toEqual(true)
    expect(peatonal.estaHabilitado()).toEqual(false)

    interseccion.pasaronQuinceSegundos();
    expect(calle.estaHabilitado()).toEqual(false)
    expect(peatonal.estaHabilitado()).toEqual(true)

    interseccion.pasaronQuinceSegundos();
    expect(calle.estaHabilitado()).toEqual(false)
    expect(peatonal.estaHabilitado()).toEqual(true)

    interseccion.pasaronQuinceSegundos();
    expect(calle.estaHabilitado()).toEqual(true)
    expect(peatonal.estaHabilitado()).toEqual(false)
});